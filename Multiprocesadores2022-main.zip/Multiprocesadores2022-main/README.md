# Multiprocesadores2022

- En este repositorio, podremos encontrar los trabajos realizados a lo largo del semestre Agosto-Diciembre 2022 de la materia de Multiprocesadores TE3061.1.
- Estos se dividiran por carpetas las cuales seran llamadas de acuerdo a su número de actividad (exeptuando actividad 1.0  la cual estara listada como act 1 al igual que la act 1.2 la cual se encontrará como Act 2)
- Como evidencias se  mostrarán archivos pdf, txt, png y bmp.
- La descripción de los códigos mostrados se encontaran en el Wiki de este repositorio. 
- - Link:
https://github.com/Xuxumin99/Multiprocesadores2022/wiki

- Solo se uso lenguaje C.
